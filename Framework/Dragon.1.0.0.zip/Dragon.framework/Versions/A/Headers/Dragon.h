//
//  Dragon.h
//  Dragon
//
//  Created by Tomohiro Ryumura on 13/02/15.
//  Copyright (c) 2013年 Tomohiro Ryumura. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Dragon : NSObject

@end
